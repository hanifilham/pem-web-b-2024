// Tambahkan interaktivitas jika diperlukan di sini
document.addEventListener('DOMContentLoaded', function() {
   
});